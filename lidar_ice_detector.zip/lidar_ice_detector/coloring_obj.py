from settings import obj_path, textured_im
from vedo import *
from segmentation import segment_im
import numpy as np
import vtk

jpg_path = textured_im

try:
    data = segment_im() # Assuming segment_im() returns a list of numpy arrays
    print("Data from segment_im():", data)
except Exception as e:
    print(f"Error in segment_im(): {e}")
    exit()


mesh = Mesh(obj_path).scale(10).pos(0,0,0)
mesh.texture(jpg_path, scale=0.1)

vertices = mesh.vertices
polygons = mesh.faces()

# Find the minimum Z coordinate for the points in the 'data' region.  We'll use
# this to normalize the height for coloring.
min_z = float('inf')
max_z = float('-inf')  # Initialize max_z to negative infinity
vertices_colored = 0 # Keep track of the number of vertices colored
colored_vertices_indices = []  # Store indices of colored vertices

#  Create a kd-tree for efficient lookup
kdtree = vtk.vtkKdTreePointLocator()
kdtree.SetDataSet(mesh.dataset) #Use mesh.dataset instead of mesh.polydata()
kdtree.BuildLocator()

# Prepare a list to store vertex colors
vertex_colors = np.zeros((len(vertices), 3))  # Initialize with black

for i in range(len(vertices)):
    x, y, z = vertices[i]
    
    # Check if (x, y) is in the data region using the KdTree
    closest_point_id = kdtree.FindClosestPoint((x, y, z))
    closest_point = mesh.vertices[closest_point_id]

    # Define a tolerance for proximity (adjust as needed)
    tolerance = 0.1  # Adjust this value based on your model and data

    # Check if (x, y) is inside any of the detected masks
    if isinstance(data, list):  # Make sure data is a list
        for mask_idx, mask in enumerate(data):  # Iterate through the masks
            if isinstance(mask, np.ndarray): #Make sure the mask is a numpy array

                # Use a point-in-polygon test to check if (x, y) is inside the mask
                # This assumes the mask is a polygon defined by the vertices in the numpy array

                # Create a vtkPolyData to represent the polygon
                polydata = vtk.vtkPolyData()
                points = vtk.vtkPoints()
                verts = vtk.vtkCellArray()

                for j in range(mask.shape[0]):
                    points.InsertNextPoint(mask[j][0], mask[j][1], 0) #Insert the points

                # Create a cell for the polygon
                verts.InsertNextCell(mask.shape[0])
                for j in range(mask.shape[0]):
                    verts.InsertCellPoint(j)

                # Assign the points and vertices to the polydata
                polydata.SetPoints(points)
                polydata.SetVerts(verts)

                # Use vtkPointInPolygon to determine if the point is inside the polygon
                locator = vtk.vtkPointLocator()
                locator.SetDataSet(polydata)
                locator.BuildLocator()

                inside = locator.FindClosestPoint((x, y, 0))

                if inside >= 0: # Point is inside the polygon
                    min_z = min(min_z, z)
                    max_z = max(max_z, z)
                    vertices_colored += 1 # increment counter
                    colored_vertices_indices.append(i) #Store the vertex index!
                    break # No need to check other polygons

            else:
                print("Error: mask is not a numpy array.")
                exit()
    else:
        print("Error: data is not a list.")
        exit()

if min_z == float('inf'):
    print("No vertices found in the specified data region.")
    exit()

save_height = max_z - min_z

print(f"Min Z: {min_z}, Max Z: {max_z}, Save Height: {save_height}")  # Print Z values
print(f"Number of Vertices Colored: {vertices_colored}") #Print number of vertices colored

for i in colored_vertices_indices: #Use the indices we saved!
    x, y, z = vertices[i]
    
    # Check if (x, y) is in the data region
    closest_point_id = kdtree.FindClosestPoint((x, y, z))
    closest_point = mesh.vertices[closest_point_id]

    # Define a tolerance for proximity (adjust as needed)
    tolerance = 0.1  # Adjust this value based on your model and data

    if isinstance(data, list):  # Make sure data is a list
        for mask_idx, mask in enumerate(data):  # Iterate through the masks
            if isinstance(mask, np.ndarray): #Make sure the mask is a numpy array

                # Use a point-in-polygon test to check if (x, y) is inside the mask
                # This assumes the mask is a polygon defined by the vertices in the numpy array

                # Create a vtkPolyData to represent the polygon
                polydata = vtk.vtkPolyData()
                points = vtk.vtkPoints()
                verts = vtk.vtkCellArray()

                for j in range(mask.shape[0]):
                    points.InsertNextPoint(mask[j][0], mask[j][1], 0) #Insert the points

                # Create a cell for the polygon
                verts.InsertNextCell(mask.shape[0])
                for j in range(mask.shape[0]):
                    verts.InsertCellPoint(j)

                # Assign the points and vertices to the polydata
                polydata.SetPoints(points)
                polydata.SetVerts(verts)

                # Use vtkPointInPolygon to determine if the point is inside the polygon
                locator = vtk.vtkPointLocator()
                locator.SetDataSet(polydata)
                locator.BuildLocator()

                inside = locator.FindClosestPoint((x, y, 0))

                if inside >= 0: # Point is inside the polygon
                    height = z - min_z

                    # Normalize the height to a range between 0 and 1
                    normalized_height = height / save_height

                    # Calculate color based on normalized height
                    blue_color = 255 * normalized_height
                    red_color = 255 * (1 - normalized_height)

                    # Assign the color to the vertex
                    vertex_colors[i] = [red_color, 0, blue_color]
                    break # No need to check other polygons

            else:
                print("Error: mask is not a numpy array.")
                exit()
    else:
        print("Error: data is not a list.")
        exit()

# Assign the vertex colors to the mesh
mesh.vertexcolors = vertex_colors

# Remove the texture so we can actually see the colors
mesh.texture(None) #remove the texture

# Show the colored mesh
show(mesh, axes=1)
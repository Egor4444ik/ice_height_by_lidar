from ultralytics import YOLO
from settings import screenshot_path, ice_model

def segment_im():

    model = YOLO(ice_model)

    CONF_THRESHOLD = 0.01
    IOU_THRESHOLD = 0.001
    results = model(screenshot_path, conf=CONF_THRESHOLD, iou=IOU_THRESHOLD, verbose=True)

    #results[0].show()  # Отображение результатов (удалено из возвращаемого значения)

    if results and results[0].masks:
        masks = results[0].masks
        return masks.xy
    else:
        print("Объекты не обнаружены или нет данных о масках.")
        return None


if __name__ == '__main__':
    segmented_results = segment_im()

    if segmented_results:
        print("Обнаружены сегментированные объекты:")
    else:
        print("Сегментированные объекты не обнаружены.")